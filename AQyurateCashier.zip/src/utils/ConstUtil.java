package utils;

import models.User;

public class ConstUtil {
    
    public static final String DRIVER_MYSQL = "com.mysql.jdbc.Driver";
    public static User auth = null;
}
